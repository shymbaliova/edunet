<?php
/**
 * The single page posts loop.
 *
 */
?>

<?php

	/* Use the framework blog page post loop. */
	PC_Template_Parts::single_page_loop();

?>