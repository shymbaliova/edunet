<?php
// Load WordPress test environment
// https://github.com/nb/wordpress-tests
//
// The path to wordpress-tests
$path = 'wordpress-tests/init.php';

require_once $path;
